declare module "@salesforce/contentAssetUrl/Cookpatternv1" {
    var Cookpatternv1: string;
    export default Cookpatternv1;
}