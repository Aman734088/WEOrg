declare module "@salesforce/messageChannel/Record_Selected__c" {
    var Record_Selected: string;
    export default Record_Selected;
}