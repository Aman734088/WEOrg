declare module "@salesforce/resourceUrl/d3" {
    var d3: string;
    export default d3;
}