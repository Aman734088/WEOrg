declare module "@salesforce/contentAssetUrl/Cookpatternv2" {
    var Cookpatternv2: string;
    export default Cookpatternv2;
}