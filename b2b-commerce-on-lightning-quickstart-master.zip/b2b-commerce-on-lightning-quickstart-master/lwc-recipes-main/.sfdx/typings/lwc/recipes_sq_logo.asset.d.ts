declare module "@salesforce/contentAssetUrl/recipes_sq_logo" {
    var recipes_sq_logo: string;
    export default recipes_sq_logo;
}