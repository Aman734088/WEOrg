declare module "@salesforce/contentAssetUrl/recipeslogo600x1201" {
    var recipeslogo600x1201: string;
    export default recipeslogo600x1201;
}