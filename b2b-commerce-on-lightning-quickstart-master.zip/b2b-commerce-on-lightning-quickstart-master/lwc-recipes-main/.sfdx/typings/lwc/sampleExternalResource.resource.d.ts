declare module "@salesforce/resourceUrl/sampleExternalResource" {
    var sampleExternalResource: string;
    export default sampleExternalResource;
}