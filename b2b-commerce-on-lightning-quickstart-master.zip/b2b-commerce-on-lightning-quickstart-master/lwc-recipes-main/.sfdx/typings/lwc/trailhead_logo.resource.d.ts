declare module "@salesforce/resourceUrl/trailhead_logo" {
    var trailhead_logo: string;
    export default trailhead_logo;
}