declare module "@salesforce/contentAssetUrl/Cookpatternv11" {
    var Cookpatternv11: string;
    export default Cookpatternv11;
}