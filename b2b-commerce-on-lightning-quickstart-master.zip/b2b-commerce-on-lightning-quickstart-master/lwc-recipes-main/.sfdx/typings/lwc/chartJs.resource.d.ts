declare module "@salesforce/resourceUrl/chartJs" {
    var chartJs: string;
    export default chartJs;
}