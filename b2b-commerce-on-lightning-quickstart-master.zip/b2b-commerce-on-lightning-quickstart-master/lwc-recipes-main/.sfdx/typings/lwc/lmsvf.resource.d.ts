declare module "@salesforce/resourceUrl/lmsvf" {
    var lmsvf: string;
    export default lmsvf;
}