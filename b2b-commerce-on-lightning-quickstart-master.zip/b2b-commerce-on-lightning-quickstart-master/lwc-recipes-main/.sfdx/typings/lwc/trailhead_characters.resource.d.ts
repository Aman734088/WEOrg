declare module "@salesforce/resourceUrl/trailhead_characters" {
    var trailhead_characters: string;
    export default trailhead_characters;
}