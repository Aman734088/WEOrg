declare module "@salesforce/contentAssetUrl/recipeslogo600x120" {
    var recipeslogo600x120: string;
    export default recipeslogo600x120;
}