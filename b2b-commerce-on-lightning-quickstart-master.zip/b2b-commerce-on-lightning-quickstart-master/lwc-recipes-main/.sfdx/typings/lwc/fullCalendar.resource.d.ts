declare module "@salesforce/resourceUrl/fullCalendar" {
    var fullCalendar: string;
    export default fullCalendar;
}