export const Account = {
    Name: { fieldApiName: 'Name' },
    AreaNumber__c: { fieldApiName: 'AreaNumber__c' }
};
