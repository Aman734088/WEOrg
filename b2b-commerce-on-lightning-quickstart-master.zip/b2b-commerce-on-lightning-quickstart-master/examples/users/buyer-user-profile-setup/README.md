# Buyer User Profile Setup
This section will help you to quickly create a profile for the buyer user in B2B for Lightning experience, with all the necessary user permissions and CRUD access object permissions.

## Use Metadata API to deploy this using Workbench:
 1. From this folder as your current location, create a .zip file: 
	```zip -r -X <your-zip-file>.zip *```
 2. Open Workbench and go to migration -> deploy.
 3. Select the file you created ( ```<your-zip-file>.zip``` ).
 4. Check the "Single Package" checkbox on that page.
 5. Click "Next".
 6. Click "Deploy".
