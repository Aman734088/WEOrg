# Integration Tests

Apex tests that use existing data in the org and verify that the Quick Start created the records that it was supposed to create.


To be run after the full Quick Start execution with the command
```
sfdx force:apex:test:run -y -r human
```
